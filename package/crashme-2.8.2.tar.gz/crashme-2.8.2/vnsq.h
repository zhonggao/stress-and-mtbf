void init_vnsq(unsigned long seed);
unsigned long vnsq_int32(void);
