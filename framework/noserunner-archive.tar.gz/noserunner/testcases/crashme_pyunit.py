'''
Created on 2014-8-21

@author: yileiwax
'''
import unittest
import crashme

class test(unittest.TestCase):
    def setUp(self):
        self.crashme=crashme.Crashme()

    def tearDown(self):
        pass


    def test_crashme(self):
        self.assertTrue(self.crashme.crashme(), "crashme test_crashme")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()