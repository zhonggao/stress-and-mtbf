'''
Created on 2014-8-20

@author: yileiwax
'''
import unittest
import flailsystem

class test(unittest.TestCase):
    def setUp(self):
        self.flailsystem=flailsystem.FlailSystem()


    def tearDown(self):
        pass


    def test_flail_system(self):
        self.assertTrue(self.flailsystem.flail_system(), "flailsystem test_flail_system")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()