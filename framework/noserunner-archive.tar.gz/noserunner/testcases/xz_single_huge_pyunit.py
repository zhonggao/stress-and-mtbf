'''
Created on 2014-8-14

@author: yileiwax
'''
import unittest
import xz_single_huge

class test(unittest.TestCase):


    def setUp(self):
        self.xz_single_huge=xz_single_huge.XZSingleHuge()


    def tearDown(self):
        pass


    def test_compress_huge_file(self):
        self.assertTrue(self.xz_single_huge.compress_huge_file(), "xz_single_huge test_compress_huge_file")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_compress_huge_file']
    unittest.main()