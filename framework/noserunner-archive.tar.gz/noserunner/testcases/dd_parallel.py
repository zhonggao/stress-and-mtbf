'''
Created on 2014-8-11

@author: yileiwax
'''

import sys
import log
import os

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_004/"
global SAVE_SIZE
SAVE_SIZE= 100 * 1024
global COUNT_NUM
COUNT_NUM= 1
global RAW_SAVE_PATH
RAW_SAVE_PATH = "/dev/sdb1"
global FILE_SAVE_PATH
FILE_SAVE_PATH = "/opt/stability/tmp/CLR_SST_004.txt"
global TMP_PATH
TMP_PATH = "/opt/stability/tmp/"

class DDParallel:
    def __init__(self):
        if not os.path.exists(LOG_FILE):
            os.makedirs(LOG_FILE)
        if os.path.exists(FILE_SAVE_PATH):
            os.remove(FILE_SAVE_PATH)
        if not os.path.exists(TMP_PATH):
            os.makedirs(TMP_PATH)
        os.system("mkdir -p " + LOG_FILE)

    def raw_write(self):
        log.log_info("Raw write start to run. ",LOG_FILE + "raw_write.log")
        sys.stdout.flush()
        dd_raw_write = 'dd if=/dev/zero of=%s bs=%dk count=%d' % (RAW_SAVE_PATH,SAVE_SIZE,COUNT_NUM)
        os.system(dd_raw_write)
        #check the file
        if os.path.exists(RAW_SAVE_PATH)==True:
            return True
        else:
            log.log_info("Raw write failed.",LOG_FILE+ "raw_write.log")
            return False

    def raw_read(self):
        log.log_info("Raw read start to run. ",LOG_FILE + "raw_read.log")
        sys.stdout.flush()
        dd_raw_read = 'dd if=%s of=/dev/null bs=%dk count=%d' % (RAW_SAVE_PATH,SAVE_SIZE,COUNT_NUM)
        try:
            os.system(dd_raw_read)
        except Exception as e:
            log.log_info("Raw read failed. Because" + str(e) ,LOG_FILE + "raw_read.log")
            return False
        return True

    def file_write(self):
        log.log_info("File write start to run. ",LOG_FILE + "file_write.log")
        sys.stdout.flush()
        dd_file_write = 'dd if=/dev/zero of=%s bs=%dk count=%d' % (FILE_SAVE_PATH,SAVE_SIZE,COUNT_NUM)
        os.system(dd_file_write)
        #check the file
        if os.path.exists(FILE_SAVE_PATH)==True:
            return True
        else:
            log.log_info("File write failed.",LOG_FILE + "file_write.log")
            return False
        os.system(dd_file_write)
    def file_read(self):
        log.log_info("File read start to run. ",LOG_FILE + "file_read.log")
        sys.stdout.flush()
        dd_file_read = 'dd if=%s of=/dev/null bs=%dk count=%d' % (FILE_SAVE_PATH,SAVE_SIZE,COUNT_NUM)
        try:
            os.system(dd_file_read)
        except Exception as e:
            log.log_info("File read failed. Because" + str(e) ,LOG_FILE + "file_read.log")
            return False
        return True