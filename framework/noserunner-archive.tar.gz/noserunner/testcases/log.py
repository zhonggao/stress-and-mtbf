'''
Created on 2014-8-12

@author: yileiwax
'''
import logging
import os

global LOG_PATH
LOG_PATH= "/opt/stability/log/"
def log_info(msg,file_name):
    #make sure the path of file_name is exists
    if os.path.exists(LOG_PATH)==True:
        pass
    else:
        os.makedirs(LOG_PATH)
    logger = logging.getLogger()
    file = logging.FileHandler(file_name)
    logger.addHandler(file)
    #set formater  
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file.setFormatter(formatter)
    #set log level  
    logger.setLevel(logging.NOTSET)
    logger.info(msg)
