# coding: utf-8
'''
Created on 2014-8-26

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_029.log"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/stress_ftp/"
global FTP_DOWNLOAD
FTP_DOWNLOAD = "ftp://clr-test.sh.intel.com:2021/ftptest"
global FTP_UPLOAD
FTP_UPLOAD = "ftp://clr-test.sh.intel.com:2021/upload/"
global FTP_UPLOAD_FILE
FTP_UPLOAD_FILE = "/opt/stability/resource/iozone/iozone"
global SCRIPTS
SCRIPTS = "/opt/stability/resource/scripts/"

class FTPStress():
    def __init__(self):
        os.system("zypper -n in curl")
        os.system("zypper -n in expect")
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)

    def stress_ftp_download(self):
        os.system("cd "+ TMP_FLIE_PATH + " ; wget " + FTP_DOWNLOAD)
        if os.path.exists(TMP_FLIE_PATH + "ftptest"):
            return True
        else:
            log.log_info("The stress_ftp_download failed, because ftptest can't find.", LOG_FILE)
            return False

    def stress_ftp_upload(self):
        try:
            os.system("curl -T /opt/stability/resource/iozone/iozone ftp://clr-test.sh.intel.com:2021/upload/")
            #os.system("curl –T " +FTP_UPLOAD_FILE + " " + FTP_UPLOAD)
            os.system("expect " + SCRIPTS + "remove.expect")
        except Exception as e:
            log.log_info("The stress ftp upload failed. Because " + str(e) , LOG_FILE)
            return False
        return True