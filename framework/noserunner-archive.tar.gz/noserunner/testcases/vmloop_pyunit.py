'''
Created on 2014-8-25

@author: yileiwax
'''
import unittest
import vmloop

class test(unittest.TestCase):

    def setUp(self):
        self.vmloop=vmloop.VMLoop()


    def tearDown(self):
        pass


    def test_spawn_vms(self):
        self.assertTrue(self.vmloop.spawn_vms(), "vmloop test_spawn_vms")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()