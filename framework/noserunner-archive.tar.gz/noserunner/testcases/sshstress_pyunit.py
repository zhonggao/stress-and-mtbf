'''
Created on 2014-8-27

@author: yileiwax
'''
import unittest
import sshstress

class Test(unittest.TestCase):


    def setUp(self):
        self.sshstress=sshstress.SSHStress()



    def tearDown(self):
        pass


    def test_stress_ssh(self):
        self.assertTrue(self.sshstress.stress_ssh(), "sshstress test_stress_ssh")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()