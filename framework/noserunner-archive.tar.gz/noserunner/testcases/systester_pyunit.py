'''
Created on 2014-8-26

@author: yileiwax
'''
import unittest
import systester

class test(unittest.TestCase):
    def setUp(self):
        self.systester=systester.SysTester()


    def tearDown(self):
        pass


    def test_systester(self):
        self.assertTrue(self.systester.systester(), "systester test_systester")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()