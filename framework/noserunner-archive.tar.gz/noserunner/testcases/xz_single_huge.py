'''
Created on 2014-8-14

@author: yileiwax
'''
import os
import log
from time import sleep

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_006.log"
global FLIE_PATH
FLIE_PATH = "/opt/stability/resource/linux-3.16/"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/linux-3.16_XZ/"
global TAR_FILE
TAR_FILE = "/opt/stability/tmp/linux-3.16_XZ.tar"
global RESULT_FILE
RESULT_FILE="/opt/stability/tmp/linux-3.16_XZ.tar.xz"

class XZSingleHuge():
    def __init__(self):
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)
        if os.path.exists(TAR_FILE):
            os.remove(TAR_FILE)
        if os.path.exists(RESULT_FILE):
            os.remove(RESULT_FILE)
        os.system("cp -r " + FLIE_PATH +"* " + TMP_FLIE_PATH)

    def compress_huge_file(self):
        os.system("tar -cvf "+ TAR_FILE +" " + TMP_FLIE_PATH)
        log.log_info("The linux kernel has been tar.", LOG_FILE)
        sleep(10)
        os.system("xz -zk " + TAR_FILE )
        if os.path.exists(RESULT_FILE):
            return True
        else:
            log.log_info("Can't xz the linux kernel.", LOG_FILE)
            return False