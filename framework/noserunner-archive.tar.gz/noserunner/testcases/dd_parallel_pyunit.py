'''
Created on 2014-8-8

@author: yileiwax
'''
import unittest
import dd_parallel

class test(unittest.TestCase):
    def setUp(self):
        self.dd_parallel=dd_parallel.DDParallel()
    def tearDown(self):
        pass
    def test_raw_write(self):
        self.assertTrue(self.dd_parallel.raw_write(), "dd_parallel test_raw_write")
    def test_raw_read(self):
        self.assertTrue(self.dd_parallel.raw_read(), "dd_parallel test_raw_read")
    def test_file_write(self):
        self.assertTrue(self.dd_parallel.file_write(), "dd_parallel test_file_write")
    def test_file_read(self):
        self.assertTrue(self.dd_parallel.file_read(), "dd_parallel test_file_read")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()