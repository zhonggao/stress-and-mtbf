'''
Created on 2014-8-14

@author: yileiwax
'''

import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_005.log"
global KERNEL_PATH
KERNEL_PATH = "/opt/stability/resource/linux-3.16/"
global TMP_KERNEL_PATH
TMP_KERNEL_PATH = "/opt/stability/tmp/linux-3.16/"
global COMPILE_KERNEL_PATH
COMPILE_KERNEL_PATH = "/opt/stability/tmp/linux-3.16/arch/x86/boot/bzImage"
global TMP_PATH
TMP_PATH = "/opt/stability/tmp/"

class KernelCompile():
    def __init__(self):
        os.system('zypper -n in -t pattern "Development Tools"')
        os.system('zypper -n in ncurses-dev')
        os.system('zypper -n in bc')
        if not os.path.exists(TMP_PATH):
            os.makedirs(TMP_PATH)
        if not os.path.exists(KERNEL_PATH):
            log.log_info("Can't find the linux kernel. Kernel compile  failed.", LOG_FILE)
        if not os.path.exists(TMP_KERNEL_PATH):
            os.makedirs(TMP_KERNEL_PATH)
        os.system("cp -r " + KERNEL_PATH +"* " + TMP_KERNEL_PATH)
        os.system("cd " + TMP_KERNEL_PATH +"; make clean")

    def stress_kernel(self):
        os.system("cd "+ TMP_KERNEL_PATH + " ; make mrproper ; make defconfig")
        os.system("cd "+ TMP_KERNEL_PATH + " ; make -j4 bzImage ")
        if os.path.exists(COMPILE_KERNEL_PATH):
            return True
        else:
            log.log_info("Kernel compile is failed.", LOG_FILE)
            return False

