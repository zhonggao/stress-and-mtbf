'''
Created on 2014-8-21

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_034.log"
global FLIE_PATH
FLIE_PATH = "/opt/stability/resource/vmloop/"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/vmloop/"

class VMLoop():
    def __init__(self):
        os.system("zypper -n in multipath-tools")
        os.system("zypper -n in rsync")
        os.system("zypper -n in qemu")
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)
        os.system("cp -r " + FLIE_PATH + "* " + TMP_FLIE_PATH)
        if not os.path.exists("/usr/share/vm-report"):
            os.makedirs("/usr/share/vm-report")
        os.system("cp " + FLIE_PATH + "vm-report.sh /usr/share/vm-report")
        os.system("cp " + FLIE_PATH + "vm-report.service /usr/share/vm-report")

    def spawn_vms(self):
        os.makedirs(TMP_FLIE_PATH + "vms")
        os.system("chmod -R 777 " + TMP_FLIE_PATH)
        os.system("cd " + TMP_FLIE_PATH + " ; ./spin-from-raw.sh clr-generic.raw")
        for i in range(20):
            os.system("cd "+ TMP_FLIE_PATH + "vms ; qemu-img create clr-"+ str(i) + ".img -b ../rootfs.img -f qcow2")
        try:
            os.system("cd "+ TMP_FLIE_PATH + " ; ./vm-loop-start -n 8 -m 340 -p clr -s .img -k BFILES/vmlinuz -i BFILES/initrd -v vms")
        except Exception as e:
            log.log_info("The spawn vms failed. Because " + str(e) , LOG_FILE)
            return False
        return True