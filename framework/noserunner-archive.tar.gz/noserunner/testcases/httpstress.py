'''
Created on 2014-8-26

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_028.log"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/stress_http/"
global WEBSITE
WEBSITE = "http://linux-ftp.jf.intel.com/pub/mirrors/ontario-canyon/snapshots/CLR-20140813/images/clr-generic.x86_64-2014.08.13.raw.xz"


class HTTPStress():
    def __init__(self):
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)

    def stress_http(self):
        os.system("cd "+ TMP_FLIE_PATH + " ; wget " + WEBSITE)
        if os.path.exists(TMP_FLIE_PATH + "clr-generic.x86_64-2014.08.13.raw.xz"):
            return True
        else:
            log.log_info("The stress_http failed, because image can't find.", LOG_FILE)
            return False