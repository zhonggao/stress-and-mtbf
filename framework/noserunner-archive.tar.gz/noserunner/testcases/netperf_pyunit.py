'''
Created on 2014-8-20

@author: yileiwax
'''
import unittest
import netperf

class test(unittest.TestCase):
    def setUp(self):
        self.netperf=netperf.NetPerf()


    def tearDown(self):
        pass


    def test_network_netperf(self):
        self.assertTrue(self.netperf.network_netperf(), "netperf test_network_netperf")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()