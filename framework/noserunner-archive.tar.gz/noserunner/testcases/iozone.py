#coding=utf-8
'''
Created on 2014-8-25

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_003/"
global FLIE_PATH
FLIE_PATH = "/opt/stability/resource/iozone/"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/iozone/"
global PROGRESS
PROGRESS = [8,64,128]
global FILE_SIZE
FILE_SIZE = ["128k","16M","256M","2G"]
global MODULE
MODULE = ["G","D"]

class IOZone():
    def __init__(self):
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)
        os.system("cp -r " + FLIE_PATH + "* " + TMP_FLIE_PATH)
        os.system("chmod -R 777 " + TMP_FLIE_PATH )
        if not os.path.exists(LOG_FILE):
            os.makedirs(LOG_FILE)

    def iozone(self):
        for i in range(len(MODULE)):
            for j in range(len(FILE_SIZE)):
                    for x in range(len(PROGRESS)):
                        try:
                            os.system("cd " + TMP_FLIE_PATH + " ; ./iozone –s " + FILE_SIZE[j] +" –i 0 –i 1 –i 2 –i 3 –i 4 –i 5 –i 8 –t " + str(PROGRESS[x]) + " –r 1m –S 2048 –" + MODULE[i] + " –o –B >> " + LOG_FILE + "test-"+MODULE[i]+FILE_SIZE[j]+str(PROGRESS[x])+".txt")
                        except Exception as e:
                            log.log_info("The iozone failed. Because " + str(e) , LOG_FILE + "CLR_SST_003.log")
                            return False
        return True