'''
Created on 2014-8-22

@author: yileiwax
'''
import unittest
import exercise_container

class test(unittest.TestCase):
    def setUp(self):
        self.exercise_container=exercise_container.ContainerExercise()


    def tearDown(self):
        pass


    def test_containers_iteratively(self):
        self.assertTrue(self.exercise_container.containers_iteratively(), "exercise_container test_containers_iteratively")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()