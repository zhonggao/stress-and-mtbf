'''
Created on 2014-8-26

@author: yileiwax
'''
import unittest
import ftpstress

class test(unittest.TestCase):


    def setUp(self):
        self.ftpstress=ftpstress.FTPStress()

    def tearDown(self):
        pass


    def test_stress_ftp_download(self):
        self.assertTrue(self.ftpstress.stress_ftp_download(), "ftpstress test_stress_ftp_download")


    def test_stress_ftp_upload(self):
        self.assertTrue(self.ftpstress.stress_ftp_upload(), "ftpstress test_stress_ftp_upload")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()