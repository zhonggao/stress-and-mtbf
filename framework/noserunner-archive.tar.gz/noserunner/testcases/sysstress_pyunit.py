'''
Created on 2014-8-20

@author: yileiwax
'''
import unittest
import sysstress

class test(unittest.TestCase):
    def setUp(self):
        self.sysstress=sysstress.SysStress()


    def tearDown(self):
        pass


    def test_stress_subsystems(self):
        self.assertTrue(self.sysstress.stress_subsystems(), "sysstress test_stress_subsystems")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()