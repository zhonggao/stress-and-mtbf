'''
Created on 2014-8-21

@author: yileiwax
'''

import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_035.log"
global TMP_CONTAINER_NAME
TMP_CONTAINER_NAME= "/opt/stability/tmp/CLR_SST_035/"
global IMAGE_REPO
IMAGE_REPO= "http://linux-ftp.jf.intel.com/pub/mirrors/ontario-canyon/snapshots/CLR-20140813/OC_Bootstrap_standard/"
global TEST_NUMBER
TEST_NUMBER= 50

class ContainerExercise():
    def __init__(self):
        if os.path.exists(TMP_CONTAINER_NAME):
            os.system("rm -rf " + TMP_CONTAINER_NAME)
        os.makedirs(TMP_CONTAINER_NAME)
        os.system("zypper -n in clr-bootstrap")
    def containers_iteratively(self):
        for i in range(TEST_NUMBER):
            os.system('/usr/bin/clr-bootstrap -d '+ TMP_CONTAINER_NAME+ "containers" + str(i)+ ' -r ' + IMAGE_REPO + ' -e "irssi wget" -n')
            #os.system("systemd-nspawn -D "+ TMP_CONTAINER_NAME+ "containers" + str(i))
            if not os.path.exists(TMP_CONTAINER_NAME+ "containers" + str(i)):
                log.log_info("The containers iteratively failed. ", LOG_FILE)
                return False
        return True
