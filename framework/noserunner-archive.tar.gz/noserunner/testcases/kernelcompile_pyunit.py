'''
Created on 2014-8-14

@author: yileiwax
'''
import unittest
import kernelcompile

class test(unittest.TestCase):


    def setUp(self):
        self.kernelcompile=kernelcompile.KernelCompile()


    def tearDown(self):
        pass


    def test_stress_kernel(self):
        self.assertTrue(self.kernelcompile.stress_kernel(), "kernelcompile test_stress_kernel")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()