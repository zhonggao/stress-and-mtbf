'''
Created on 2014-8-26

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_026.log"
global SCRIPTS
SCRIPTS = "/opt/stability/resource/scripts/"

class SSHStress():
    def __init__(self):
        os.system("zypper -n in expect")

    def stress_ssh(self):
        try:
            os.system("expect " + SCRIPTS + "remove.expect")
        except Exception as e:
            log.log_info("The stress ssh failed. Because " + str(e) , LOG_FILE)
            return False
        return True