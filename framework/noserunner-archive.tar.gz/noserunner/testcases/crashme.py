'''
Created on 2014-8-20

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_032.log"
global FLIE_PATH
FLIE_PATH = "/opt/stability/resource/crashme-2.8.2/"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/crashme-2.8.2/"

class Crashme():
    def __init__(self):
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)
        os.system("cp -r " + FLIE_PATH + "* " + TMP_FLIE_PATH)

    def crashme(self):
        os.system("cd " + TMP_FLIE_PATH +" ; make -f makefile all")
        try:
            os.system("cd " +TMP_FLIE_PATH + " ; ./crashme +2000 666 100 1:00:00")
        except Exception as e:
            log.log_info("The crashme failed. Because " + str(e) , LOG_FILE)
            return False
        return True
        