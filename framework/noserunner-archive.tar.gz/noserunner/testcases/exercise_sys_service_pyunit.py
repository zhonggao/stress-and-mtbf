'''
Created on 2014-8-21

@author: yileiwax
'''
import unittest
import exercise_sys_service

class test(unittest.TestCase):
    def setUp(self):
        self.exercise_sys_service=exercise_sys_service.SysServiceExercise()


    def tearDown(self):
        pass


    def test_exercise_system_services(self):
        self.assertTrue(self.exercise_sys_service.exercise_system_services(), "exercise_sys_service test_exercise_system_services")


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()