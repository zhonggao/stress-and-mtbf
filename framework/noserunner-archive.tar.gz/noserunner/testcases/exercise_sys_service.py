'''
Created on 2014-8-21

@author: yileiwax
'''

import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/exercise_sys_service.log"
global TEST_SERVER
TEST_SERVER=['atd.service']
global TEST_MODUL
TEST_MODUL=['restart','stop','disable','enable','kill']#reload

class SysServiceExercise():
    def __init__(self):
        pass
    def exercise_system_services(self):
        for i in range(len(TEST_SERVER)):
            for j in range(len(TEST_MODUL)):
                try:
                    os.system("systemctl " + TEST_MODUL[j] + " " + TEST_SERVER[i])
                except Exception as e:
                    log.log_info("The exercise system services failed. Because " + str(e) , LOG_FILE)
        return True