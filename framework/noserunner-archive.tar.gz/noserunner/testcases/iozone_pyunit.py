'''
Created on 2014-8-26

@author: yileiwax
'''
import unittest
import iozone

class test(unittest.TestCase):

    def setUp(self):
        self.iozone=iozone.IOZone()


    def tearDown(self):
        pass


    def test_iozone(self):
        self.assertTrue(self.iozone.iozone(), "iozone test_iozone")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()