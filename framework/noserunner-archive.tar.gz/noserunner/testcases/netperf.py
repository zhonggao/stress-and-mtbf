'''
Created on 2014-8-20

@author: yileiwax
'''
import os
import log

global LOG_FILE
LOG_FILE= "/opt/stability/log/CLR_SST_023.log"
global FLIE_PATH
FLIE_PATH = "/opt/stability/resource/netperf-2.6.0/"
global TMP_FLIE_PATH
TMP_FLIE_PATH = "/opt/stability/tmp/netperf-2.6.0/"
global TEST_IP
TEST_IP = "10.239.52.72"
global TEST_TIME
TEST_TIME = "20"
global TEST_MODEL
TEST_MODEL=["TCP_STREAM","TCP_RR","UDP_STREAM","UDP_RR"]

class NetPerf():
    def __init__(self):
        if os.path.exists(TMP_FLIE_PATH):
            os.system("rm -rf " + TMP_FLIE_PATH)
        os.makedirs(TMP_FLIE_PATH)
        os.system("cp -r " + FLIE_PATH + "* " + TMP_FLIE_PATH)

    def network_netperf(self):
        os.system("cd " + TMP_FLIE_PATH +" ; ./configure")
        os.system("cd " + TMP_FLIE_PATH + " ; make ; make install")
        os.system("/usr/local/bin/netserver")
        try:
            for i in range(len(TEST_MODEL)):
                os.system("netperf -H " + TEST_IP + " -l " + TEST_TIME + " -t " +TEST_MODEL[i])
        except Exception as e:
            log.log_info("The network netperf failed. Because " + str(e) , LOG_FILE)
            return False
        return True