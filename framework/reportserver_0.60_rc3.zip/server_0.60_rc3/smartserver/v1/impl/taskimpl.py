#!/usr/bin/env python
# -*- coding: utf-8 -*-

from db import *
from filedealer import deleteFile
from util import resultWrapper
import json, time
from datetime import datetime
from mongoengine.context_managers import switch_db
from ..config import FILE_DB_NAME

def sessionCreateEndDomainSummary(sid, endtid):
    """
       Task func to calculate the domain summary till the "session end" case
    """
    print "Start creating the end domain summary of session %s" %sid
    cases = Cases.objects(sid=sid).order_by('+tid').only('casename', 'result', 'comments')[:endtid]
    enddomaincount = {}
    for case in cases:
        if case.comments and case.comments.caseresult:
            result = case.comments.caseresult
        else:
            result = case.result
        if case.casename in enddomaincount.keys():
            enddomaincount[case.casename][result] += 1
        else:
            enddomaincount[case.casename] = {'pass': 0, 'fail': 0, 'error': 0, 'block': 0}
            enddomaincount[case.casename][result] += 1
    enddomaincount = json.dumps(enddomaincount)
    try:
        Sessions.objects(sid=sid).update(set__enddomaincount=enddomaincount)
    except OperationError:
        Sessions.objects(sid=sid).update(set__enddomaincount=enddomaincount)

def sessionUpdateEndDomainSummary(sid, results):
    """
       Task func to update session end domain count
    """
    print "Start updating the end domain summary of session %s" %sid
    enddomaincount = Sessions.objects(sid=sid).only('enddomaincount').first().enddomaincount
    if enddomaincount:
        enddomaincount = json.loads(enddomaincount)
    else:
        enddomaincount = {}
    for result in results:
        casename = Cases.objects(sid=sid, tid=result[0]).only('casename').first().casename
        if not result[2]:
            if casename in enddomaincount.keys():
                enddomaincount[casename][result[1]] += 1
            else:
                enddomaincount[casename] = {'pass': 0, 'fail': 0, 'error': 0, 'block': 0}
                enddomaincount[casename][result[1]] += 1 
        else:
            enddomaincount[casename][result[2]] -= 1
            enddomaincount[casename][result[1]] += 1
    enddomaincount = json.dumps(enddomaincount)
    try:
        Sessions.objects(sid=sid).update(set__enddomaincount=enddomaincount)
    except OperationError:
        Sessions.objects(sid=sid).update(set__enddomaincount=enddomaincount)

def sessionUpdateDomainSummary(sid, results):
    """
       Task func to update session domain count
    """
    print "Start updating the domain summary of session %s" %sid
    domaincount = Sessions.objects(sid=sid).only('domaincount').first().domaincount
    if domaincount:
        domaincount = json.loads(domaincount)
    else:
        domaincount = {}
    for result in results:
        casename = Cases.objects(sid=sid, tid=result[0]).only('casename').first().casename
        if not result[2]:
            if casename in domaincount.keys():
                domaincount[casename][result[1]] += 1
            else:
                domaincount[casename] = {'pass': 0, 'fail': 0, 'error': 0, 'block': 0}
                domaincount[casename][result[1]] += 1
        else:
            domaincount[casename][result[2]] -= 1
            domaincount[casename][result[1]] += 1
    domaincount = json.dumps(domaincount)   
    try:
        Sessions.objects(sid=sid).only('sid').update(set__domaincount=domaincount)
    except OperationError:
        Sessions.objects(sid=sid).only('sid').update(set__domaincount=domaincount)

def sessionUpdateSummary(sid, results):
    """
       Func to update session casecount summary.
    """
    print "Start updating the session summary of session %s" %sid    
    # Update session runtime here.
    cases = Cases.objects(sid=sid).order_by('-tid')
    minstarttime = cases[(len(cases) - 1)].starttime if cases[(len(cases) - 1)].starttime else cases[(len(cases) - 2)].starttime
    maxendtime = cases[0].endtime if cases[0].endtime else cases[0].starttime
    if not maxendtime:
        maxendtime = cases[1].endtime if cases[1].endtime else cases[1].starttime
    runtime = (maxendtime - minstarttime).total_seconds()
    Sessions.objects(sid=sid).update(set__runtime=runtime)

    # Update casecount here.
    session = Sessions.objects(sid=sid).only('casecount').first()
    if not session:
        return resultWrapper('error', {}, 'Invalid session ID!')
    casecount = session.casecount
    for result in results:
        if result[1] == 'running':
            status = result[0].lower()
            print 'write_status_count', status
            if status == 'error':
                Sessions.objects(sid=sid).update(inc__casecount__total=1, inc__casecount__error=1)
            elif status == 'fail':
                Sessions.objects(sid=sid).update(inc__casecount__total=1, inc__casecount__fail=1) 
            else:
                Sessions.objects(sid=sid).update(inc__casecount__total=1, inc__casecount__pass=1)
        else:
            casecount[result[1]] -= 1
            casecount[result[0]] += 1
            Sessions.objects(sid=sid).update(set__casecount=casecount)

def sessionActiveSession(sid):
    """
       Task function to clear session endtime if it has been set.
    """
    print "Start activate session %s" %sid
    session = Sessions.objects(sid=sid).only('endtime').first()
    if session.endtime:
        try:
            Sessions.objects(sid=sid).update(set__endtime=None)
        except OperationError:
            Sessions.objects(sid=sid).update(set__endtime=None)

def caseValidateEndtime():
    """
       Used to validate case endtime
    """
    print "Start validating the endtime of cases..."
    for case in Cases.objects(endtime=None, result='running'):
        if not case.starttime:
            case.delete()
        if (datetime.now() - case.starttime).total_seconds() >= 3600:
            case.update(set__endtime=case.starttime, 
                        set__result='error',
                        set__traceinfo='Case has been running for an hour, set it error')
            sessionUpdateSummary(case.sid, [['error', 'running']])
            sessionUpdateDomainSummary(case.sid, [[case.tid, 'error', '']])
            session = Sessions.objects(sid=case.sid).first()
            if session.endtid and session.endtid > case.tid:
                sessionUpdateEndDomainSummary(case.sid, [[case.tid, 'error', '']])

def sessionValidateEndtime():
    """
       Used to validate session endtime
    """
    print "Start validating the endtime of sessions..."
    for session in Sessions.objects(endtime=None).only('starttime', 'sid'):
        cases = Cases.objects(sid=session.sid).order_by('-tid')
        if not cases:
            endtime = session.starttime
        else:
            endtime = cases[0].endtime if cases[0].endtime else cases[0].starttime

        if (datetime.now() - endtime).total_seconds() >= 300:
            session.update(set__endtime=endtime)
            session.reload()

def tokenValidateExpireTime():
    """
       Used to validate token expire time and clear dirty users.
    """
    #If user has not activated itself before its token's expire time, remove this user.
    print "Start validating all the tokens of server" 
    users = Users.objects(active=False).only('uid')
    for user in users:
        if (time.time() - UserTokens.objects(uid=user.uid).first().expires) >= 0:
            user.delete()
    #If token has expired, remove it from database.
    for usertoken in UserTokens.objects():
        if (time.time() - usertoken.expires) >= 0:
            UserTokens.objects(token=usertoken.token).delete()

def _getID(url):
    return url['url'].strip().replace('/file/', '')

def sessionRemoveAll(sid):
    """
       Task to remove all the cases of a session and case log/snapshots 
    """
    print "Start remove session %s" %sid
    fid = []
    for case in Cases.objects(sid=sid, result='fail').only('log', 'expectshot', 'snapshots'):
        if case.log:
            fid.append(_getID(case.log))
        if case.expectshot:
            fid.append(_getID(case.expectshot))
        if case.snapshots:
            for snap in case.snapshots:
                fid.append(_getID(snap))
    try:
        Cases.objects(sid=sid).delete()
    except OperationError:
        Cases.objects(sid=sid).delete()

    deleteFile(fid)

def groupRemoveAll(gid):
    """
       Task to remove all the sessions of a group.
    """
    for session in Sessions.objects(gid=gid):
        sessionRemoveAll(session.sid)
    try:
        Sessions.objects(gid=gid).delete()
    except OperationError:
        Sessions.objects(gid=gid).delete()

def _dirtyFileRemoveAll():
    #Remove dirty records in Files.
    casefileids, avatarids = set(), set()
    with switch_db(Files, FILE_DB_NAME) as File:
        fileids = set(File.objects().distinct('fileid'))
    for case in Cases.objects(result='fail'):
        if case.log:
            casefileids.add(_getID(case.log))
        if case.expectshot:
            casefileids.add(_getID(case.expectshot))
        if case.snapshots:
            for snap in case.snapshots:
                casefileids.add(_getID(snap))
    for user in Users.objects():
        if user.avatar:
            avatarids.add(_getID(user.avatar))

    deleteFile((fileids - casefileids - avatarids))

def _dirtyCaseRemoveAll():
    #Remove dirty records in Cases
    casesids = set(Cases.objects().distinct('sid'))
    sessionids = set(Sessions.objects().distinct('sid'))

    for sid in casesids - sessionids:
        try:
            Cases.objects(sid=sid).delete()
        except OperationError:
            Cases.objects(sid=sid).delete()

def _dirtySessionRemoveAll():
    #Remove dirty records in Sessions.
    sessiongids = set(Sessions.objects().distinct('gid'))
    groupids = set(Groups.objects().distinct('gid'))

    for gid in sessiongids - groupids:
        try:
            Sessions.objects(gid=gid).delete()
        except OperationError:
            Sessions.objects(gid=gid).delete()

def _dirtyGroupMemberRemoveAll():
    #Remove dirty records in GroupMembers.

    membergids = set(GroupMembers.objects().distinct('gid'))
    groupids = set(Groups.objects().distinct('gid'))

    for gid in membergids - groupids:
        try:
            GroupMembers.objects(gid=gid).delete()
        except OperationError:
            GroupMembers.objects(gid=gid).delete()

def _dirtyCyclesRemoveAll():
    #Remove dirty records in Cycles.
    cyclesids = set()
    for cycle in Cycles.objects():
        cyclesids.update(cycle.sids)
    sessionids = set(Sessions.objects().distinct('sid'))

    for sid in cyclesids - sessionids:
        cycle = Cycles.objects(sids=sid).first()
        try:
            cycle.update(pull__sids=sid)
            cycle.reload()
            if not cycle.sids:
                cycle.delete()
        except OperationError:
            cycle.update(pull__sids=sid)
            cycle.reload()
            if not cycle.sids:
                cycle.delete()            

def dirtyDataRemoveAll():
    """
       Scheduled task to remove all the dirty data(file, case, session) from database
    """
    print "Start removing all the dirty files of server" 
    _dirtyGroupMemberRemoveAll()
    _dirtyCyclesRemoveAll()
    _dirtySessionRemoveAll()
    _dirtyCaseRemoveAll()
    _dirtyFileRemoveAll()
