#!/usr/bin/env python
# -*- coding: utf-8 -*-

from .v1.config import *

__all__ = ["MONGODB_URI", "MONGODB_REPLICASET", "MONGODB_PORT", "WEB_HOST", "WEB_PORT"]
